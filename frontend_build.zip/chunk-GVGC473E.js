var a=class{fields="";orderBy="";searchQuery="";pageSize=30;skip=0;name="";totalCount=0;metaTags=""};export{a};
