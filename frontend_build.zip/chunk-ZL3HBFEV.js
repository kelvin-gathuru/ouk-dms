import{g as o}from"./chunk-KZMFGXDY.js";var _=new o("MAT_INPUT_VALUE_ACCESSOR");export{_ as a};
