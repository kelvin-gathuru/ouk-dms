import{a}from"./chunk-DP3RHJJS.js";import"./chunk-H5HZ6YB3.js";export default a();
