var I=(E=>(E[E.STRING=0]="STRING",E[E.DATETIME=1]="DATETIME",E))(I||{});export{I as a};
