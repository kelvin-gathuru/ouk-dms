import{a as r}from"./chunk-GVGC473E.js";var e=class extends r{id="";userName=""};export{e as a};
