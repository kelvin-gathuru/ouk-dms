import{a as s}from"./chunk-GVGC473E.js";var t=class extends s{subject;message;frequency};export{t as a};
