var i=(d=>(d[d.Initiated=0]="Initiated",d[d.InProgress=1]="InProgress",d[d.Completed=2]="Completed",d[d.Cancelled=3]="Cancelled",d[d.All=4]="All",d))(i||{});export{i as a};
